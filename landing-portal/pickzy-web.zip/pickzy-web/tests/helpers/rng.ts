/** Deterministic random sources for tests. */
export function sequenceRng(values: number[]) {
  let i = 0;
  return () => values[i++ % values.length];
}

/** Small seeded PRNG (mulberry32) for statistical tests. */
export function seededRng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
